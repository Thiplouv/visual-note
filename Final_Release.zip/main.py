# -*- coding: utf-8 -*-
from tkinter import *
import tkinter as tk
from tkinter import messagebox
from fn_main import *
import fn_main as fmn


fmn.accmain()
